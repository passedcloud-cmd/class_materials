############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 제한 내장 함수:  max, min
# 기본 점수 (9점): 제한 내장 함수를 사용하여 해결
# 가산점(+3점): 제한 내장 함수 없이 직접 구현 (총 12점)

def find_price_range(prices):
    # 가격이 1개 뿐인 경우를 처리
    if len(prices) == 1:
        result = 0
    else:
        # 최고가 찾기
        maximal_price = prices[0]
        for i in prices:
            if i > maximal_price:
                maximal_price = i

        # 최저가 찾기
        minimal_price = prices[0]
        for i in prices:
            if i < minimal_price:
                minimal_price = i

        # 최고가와 최저가의 차이
        result = maximal_price - minimal_price

    return result

    # 여기에 코드를 작성하여 함수를 완성합니다.

# 추가 테스트를 위한 코드 작성 가능
# 예) print(함수명(인자))

#####################################################
# 아래 코드를 삭제하는 경우 
# 모든 책임은 삭제한 본인에게 있습니다. 
############## 테스트 코드 삭제 금지 #################
print(find_price_range([1000, 2500, 1800, 3000, 2200]))  # 2000 (3000 - 1000)
print(find_price_range([500]))                           # 0
#####################################################
