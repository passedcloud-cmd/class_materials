############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 제한 내장 함수: map, max, sum
# 기본 점수 (9점): 제한 내장 함수를 사용하여 해결
# 가산점(+3점): 제한 내장 함수 없이 직접 구현 (총 12점)

def sum_row_maximums(matrix):
    sum_maximal_number = 0
    
    # 중첩된 리스트니까 for문도 2번 중첩
    for i in matrix:
        maximal_number = i[0]
        for j in i:
            if j > maximal_number:
                maximal_number = j
        sum_maximal_number += maximal_number
    return sum_maximal_number
            


    # 여기에 코드를 작성하여 함수를 완성합니다.

# 추가 테스트를 위한 코드 작성 가능
# 예) print(함수명(인자))

#####################################################
# 아래 코드를 삭제하는 경우 
# 모든 책임은 삭제한 본인에게 있습니다. 
############## 테스트 코드 삭제 금지 #################
print(sum_row_maximums([[10, 3, 7], [2, 9, 4], [6, 1, 8]]))  # 27
print(sum_row_maximums([[-1, -2, -3], [-10, -5, -1], [-100, -200, -300]]))  # -102
print(sum_row_maximums([[5]]))  # 5
#####################################################